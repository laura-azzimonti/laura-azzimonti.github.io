###############################################################
###    MOXstat
###    Author: L. Azzimonti
###    Title: "Blood flow velocity field estimation via spatial regression with PDE penalization"
###    In collaboration with: L.M. Sangalli, P. Secchi, F. Nobile
###    Reference: "Blood flow velocity field estimation via spatial regression with PDE penalization"
###    Date: June 17, 2014
###############################################################
rm(list=ls())

library(plotrix)

#caso=simulazione
#	28 = CASE STUDY D
#	29 = CASE STUDY E
#	40 = CASE STUDY A
#	41 = CASE STUDY B
#	42 = CASE STUDY C


caso=40
newpoints=TRUE
lattice=TRUE

if(caso>=40){
point=TRUE
}else if(caso<=30){
point=FALSE
}

extraevaluations=TRUE
if(caso<40){
extraevaluations=FALSE
}

geom=TRUE


distEvec<-function(v,p){
d=sqrt((p[1]-v[,1])^2+(p[2]-v[,2])^2)
return(d)
}
distE<-function(v,p){
d=sqrt((p[1]-v[1])^2+(p[2]-v[2])^2)
return(d)
}
angle=function(p1,p2){
if(!is.na(p1) && !is.na(p2)){
a=atan((p1[2]-p2[2])/(p1[1]-p2[1]))
if(p1[2]>p2[2]){
if(p1[1]>p2[1]){
return(a)
}
else{
return(pi+a)
}
}
if(p1[2]<p2[2]){
if(p1[1]>p2[1]){
return(2*pi+a)
}
else{
return(pi+a)
}
}
}
else{
return(NA)
}
}


GEOM=read.table('geom_simulazioni.txt')
ntheta=dim(GEOM)[1]
M=colMeans(GEOM)
GEOM0=cbind(GEOM[,1]-M[1],GEOM[,2]-M[2])
index_bound=rep(0:1, ntheta/2)
XYbound=cbind(GEOM[index_bound==1,1],GEOM[index_bound==1,2])
XYbound[,1]=XYbound[,1]-M[1]
XYbound[,2]=XYbound[,2]-M[2]
n_bound=dim(XYbound)[1]
thetabound=rep(0,n_bound)
Rbound=distEvec(XYbound,c(0,0))
for(i in 1:n_bound){
thetabound[i]=angle(XYbound[i,],c(0,0))
}
XYbound_out=cbind(1.2*Rbound*cos(thetabound),1.2*Rbound*sin(thetabound))
XYbound=rbind(XYbound_out,XYbound)


if(newpoints){
searchmax=c(GEOM[which.max(GEOM[,2]),1], GEOM[which.min(GEOM[,2]),1])
centrox=(GEOM[which.min(GEOM[,2]),1]+GEOM[which.max(GEOM[,2]),1])/2
centroy=colMeans(GEOM)[2]
M=c(centrox,centroy)
if(lattice){
ngrid_b=200
grid_b_x=seq(min(GEOM0[,1])-0.5,max(GEOM0[,1])+0.5,0.05)
ngrid_b_x=length(grid_b_x)
grid_b_y=seq(min(GEOM0[,2])-0.5,max(GEOM0[,2])+0.5,0.05)
ngrid_b_y=length(grid_b_y)
GRID_b_x=matrix(rep(grid_b_x,ngrid_b_y),ngrid_b_x,ngrid_b_y,byrow=FALSE)
GRID_b_y=matrix(rep(grid_b_y,each=ngrid_b_x),ngrid_b_x,ngrid_b_y,byrow=FALSE)
LAB_b=matrix(0,ngrid_b_x,ngrid_b_y)
for(i in 1:ngrid_b_x){
for(j in 1:ngrid_b_y){
thetaxy=angle(c(GRID_b_x[i,j],GRID_b_y[i,j]),c(0,0))
rhoxy=distE(c(GRID_b_x[i,j],GRID_b_y[i,j]),c(0,0))
id_theta=which(thetaxy<thetabound)[1]
if(is.na(id_theta)){
id_theta=1
}
R1=Rbound[id_theta]
if(id_theta>1){
R2=Rbound[id_theta-1]
}else{
R2=Rbound[n_bound]
}
if(rhoxy<min(R1,R2)){
LAB_b[i,j]=1
}
}
}
M=c(sum(GRID_b_x*LAB_b)/sum(LAB_b),sum(GRID_b_y*LAB_b)/sum(LAB_b))
}
GEOM0[,1]=GEOM0[,1]-M[1]
GEOM0[,2]=GEOM0[,2]-M[2]
XYbound[,1]=XYbound[,1]-M[1]
XYbound[,2]=XYbound[,2]-M[2]
}

boundN=FALSE


#radius of the external domain
Rextra=1.2
#radius of the domain
R=1
#radius of subdomains
eta=0.1
eta6=2*eta
if(caso==29){
etaD=0.18
}else if(caso==28){
etaD=0.15
}else if(caso==40 | caso==41){
R=max(abs(GEOM0))
}else if(caso==42){
R=max(abs(GEOM0))
eta=0.05
eta6=2*eta
}

boundD=rep(FALSE,2*n_bound)
boundD[n_bound+1:n_bound]=TRUE

# data location generation
set.seed(600)
if(caso>=40){
n_punti=100
n_gen=0
XYunif=XYbound
XYoss=NULL
while(n_gen<n_punti){
xyunif=runif(2,-R,R)
thetaxy=angle(xyunif,c(0,0))
rhoxy=distE(xyunif,c(0,0))
id_theta=which(thetaxy<thetabound)[1]
if(is.na(id_theta)){
id_theta=1
}
R1=Rbound[id_theta]
if(id_theta>1){
R2=Rbound[id_theta-1]
}else{
R2=Rbound[n_bound]
}
if(rhoxy<min(R1,R2)){
d=distEvec(XYunif,xyunif)
if(sum(d>eta)==length(d)){
if(caso==40){
XYoss=rbind(XYoss,xyunif)
XYunif=rbind(XYunif,xyunif)
n_gen=n_gen+1
}else if(caso==41){
if(xyunif[1]*xyunif[2]>0){
XYunif=rbind(XYunif,xyunif)
XYoss=rbind(XYoss,xyunif)
n_gen=n_gen+1
}
}else if(caso==42){
if(abs(xyunif[1])<eta6 | abs(xyunif[2])<eta6){
XYunif=rbind(XYunif,xyunif)
XYoss=rbind(XYoss,xyunif)
n_gen=n_gen+1
}
}
}
}
}
}



if(caso==29){
n_punti=7
XYunif=XYbound
XYoss=NULL
XYoss=rbind(XYoss,c(0,0))
XYoss=rbind(XYoss,c(0,0.8))
XYoss=rbind(XYoss,c(0,-0.8))
XYoss=rbind(XYoss,c(0,0.4))
XYoss=rbind(XYoss,c(0,-0.4))
XYoss=rbind(XYoss,c(-0.8,0))
XYoss=rbind(XYoss,c(0.8,0))
#XYoss=rbind(XYoss,c(0.8,0))
#XYoss=rbind(XYoss,c(-0.8,0))
XYunif=rbind(XYunif,XYoss)
}else if(caso==28){
n_punti=21
XYunif=XYbound
rangeossy=2
rangeossx=2
XYoss=NULL
XYoss=rbind(XYoss,c(0,0))
XYoss=rbind(XYoss,c(0,0.8)*rangeossy/2) #0.8
XYoss=rbind(XYoss,c(0,-0.8)*rangeossy/2) 
XYoss=rbind(XYoss,c(0,0.45)*rangeossy/2) #0.4
XYoss=rbind(XYoss,c(0,-0.45)*rangeossy/2)
XYoss=rbind(XYoss,c(-0.8,0)*rangeossy/2)
XYoss=rbind(XYoss,c(0.8,0)*rangeossy/2)	
XYoss=rbind(XYoss,c(0.45,0)*rangeossy/2) #0.4
XYoss=rbind(XYoss,c(-0.45,0)*rangeossy/2) 
XYoss=rbind(XYoss,c(-0.45*sqrt(2)/2,-0.45*sqrt(2)/2)*rangeossy/2)
XYoss=rbind(XYoss,c(-0.45*sqrt(2)/2,0.45*sqrt(2)/2)*rangeossy/2)
XYoss=rbind(XYoss,c(0.45*sqrt(2)/2,-0.45*sqrt(2)/2)*rangeossy/2)
XYoss=rbind(XYoss,c(0.45*sqrt(2)/2,0.45*sqrt(2)/2)*rangeossy/2)
XYoss=rbind(XYoss,c(-0.8*sqrt(3)/2,-0.8*1/2)*rangeossy/2)
XYoss=rbind(XYoss,c(-0.8*1/2,-0.8*sqrt(3)/2)*rangeossy/2)
XYoss=rbind(XYoss,c(-0.8*sqrt(3)/2,0.8*1/2)*rangeossy/2)
XYoss=rbind(XYoss,c(-0.8*1/2,0.8*sqrt(3)/2)*rangeossy/2)
XYoss=rbind(XYoss,c(0.8*sqrt(3)/2,0.8*1/2)*rangeossy/2)
XYoss=rbind(XYoss,c(0.8*1/2,0.8*sqrt(3)/2)*rangeossy/2)
XYoss=rbind(XYoss,c(0.8*sqrt(3)/2,-0.8*1/2)*rangeossy/2)
XYoss=rbind(XYoss,c(0.8*1/2,-0.8*sqrt(3)/2)*rangeossy/2)
XYunif=rbind(XYunif,XYoss)	
}

xlim=c(-1,1)
if(point){
plot(rbind(GEOM0,GEOM0[1,]),type='l',xlab='',ylab='',asp=1,xlim=xlim,cex.main=1,main='CASE STUDY: POINTWISE DATA')
points(XYoss,lwd=2)
}
if(caso==28 | caso==29){
plot(0,0,col='white',xlab='',ylab='',asp=1,xlim=c(-1,1),ylim=c(-1,1))
plot(rbind(GEOM0,GEOM[1,]),type='l',xlab='',ylab='',asp=1,xlim=c(-1,1),cex.main=1,main='CASE STUDY: AREAL DATA')
for(i in 1:n_punti){
draw.circle(XYoss[i,1],XYoss[i,2],etaD,nv=100,border=NULL,col=NA,lty=1,lwd=2)
}
}
n_effettivi=n_punti



set.seed(700)
if(caso==40 ){
n_punti_extra=0
eta_extra=0.1
} else if(caso==41){
n_punti_extra=40
eta_extra=0.1
}else if(caso==42){
n_punti_extra=60
eta_extra=0.1
}else if(caso==29){
eta_extra=0.08
n_punti_extra=150
}else if(caso==28){
eta_extra=0.08
n_punti_extra=30
}
n_gen=0
while(n_gen<n_punti_extra){
xyunif=runif(2,-R,R)
if(caso<30){
if(xyunif[1]^2+xyunif[2]^2<R^2){
d=distEvec(XYunif,xyunif)
if(sum(d>eta_extra)==length(d)){
if(((caso==2 | caso==3) & xyunif[1]*xyunif[2]<0) | ((caso==6 | caso==7) & (abs(xyunif[1])>eta6 & abs(xyunif[2])>eta6)) | caso==10){
XYunif=rbind(XYunif,xyunif)
n_gen=n_gen+1
}else if( (caso==28 | caso==29) & sum(d[2*n_bound+1:n_effettivi]>etaD+eta_extra)==n_effettivi){
XYunif=rbind(XYunif,xyunif)
n_gen=n_gen+1
}
}
}
}else if(caso==41 | caso==42){
thetaxy=angle(xyunif,c(0,0))
rhoxy=distE(xyunif,c(0,0))
if(newpoints){
thetaxy=angle(xyunif+M,c(0,0))
rhoxy=distE(xyunif+M,c(0,0))
}
id_theta=which(thetaxy<thetabound)[1]
if(is.na(id_theta)){
id_theta=1
}
R1=Rbound[id_theta]
if(id_theta>1){
R2=Rbound[id_theta-1]
}else{
R2=Rbound[n_bound]
}
if(rhoxy<min(R1,R2)){
d=distEvec(XYunif,xyunif)
if(caso==31){
if(sum(d>eta_extra)==length(d)){
XYunif=rbind(XYunif,xyunif)
n_gen=n_gen+1
}
}else if(caso==41){
if(sum(d>eta_extra)==length(d) & xyunif[1]*xyunif[2]<0){
XYunif=rbind(XYunif,xyunif)
n_gen=n_gen+1
}
}else if(caso==42){
if(sum(d>eta_extra)==length(d) & abs(xyunif[1])>eta6 & abs(xyunif[2])>eta6){
XYunif=rbind(XYunif,xyunif)
n_gen=n_gen+1
}
}
}
}
}



set.seed(3728)
#subdomains definition
if(point){
n_int=0
}else if(!point){
n_int_b=6
n_int_i=6
n_int=n_int_b+n_int_i
theta_int=seq(0,2*pi*(1-1/n_int_b),length=n_int_b)
intorno=cbind(etaD*cos(theta_int),etaD*sin(theta_int))
intorno_i=cbind(etaD/2*cos(theta_int),etaD/2*sin(theta_int))
intorno=rbind(intorno,intorno_i)
for(i in (2*n_bound+1):(2*n_bound+n_effettivi)){
XYunif=rbind(XYunif,cbind(XYunif[i,1]+intorno[,1],XYunif[i,2]+intorno[,2]))
}
}

n_extra=0
bound=rep(FALSE,2*n_bound+n_effettivi+n_extra+n_effettivi*n_int+n_punti_extra)
boundint=rep(FALSE,n_bound+n_effettivi+n_extra+n_effettivi*n_int+n_punti_extra)
bound[1:(2*n_bound)]=boundD
boundint[1:(n_bound)]=boundD[(n_bound+1):(2*n_bound)]


n=n_effettivi


ngrid=50
if(caso>=40 | caso==28 | caso==29){
x_grid=seq(min(xlim)-0.01,max(xlim)+0.01,length=2*ngrid)
y_grid=seq(min(xlim)-0.01,max(xlim)+0.01,length=2*ngrid)
X_grid=matrix(rep(x_grid,ngrid),ngrid,ngrid)
Y_grid=matrix(rep(x_grid,each=ngrid),ngrid,ngrid)
}

Ximg=rep(x_grid,length=length(x_grid))
Ximg=matrix(Ximg,nrow=length(x_grid),ncol=length(x_grid),byrow=TRUE)

Yimg=rep(y_grid,length=length(y_grid))
Yimg=matrix(Yimg,nrow=length(y_grid),ncol=length(y_grid),byrow=FALSE)

sol_esatta=as.matrix(read.table('deformazione_sol_esatta.txt'))


devst_noise=0.1

#adding noise
sol_noise=sol_esatta+matrix(rnorm(length(x_grid)*length(y_grid),mean=0,sd=devst_noise),length(x_grid),length(y_grid))


media_sol_esatta=rep(0,n)
sd_sol_esatta=rep(0,n)
media_sol_noise=rep(0,n)
sd_sol_noise=rep(0,n)


if(caso==29 | caso==28){
for(i in 1:n_effettivi){
indicatrice=(Ximg-XYoss[i,1])^2+(Yimg-XYoss[i,2])^2<etaD^2
media_sol_esatta[i]=sum(indicatrice*sol_esatta,na.rm=TRUE)*(x_grid[2]-x_grid[1])*(y_grid[2]-y_grid[1])/(pi*etaD^2)
}
devst_noise_media=0.05
Zex=media_sol_esatta
Z=media_sol_esatta+rnorm(n,0,devst_noise_media)
}

set.seed(1030)
if(point & geom){
if(caso==40 | caso==41 | caso==42){
Zex=rep(0,n)
for(i in 1:n){
d=distEvec(cbind(as.vector(Ximg),as.vector(Yimg)),XYoss[i,])
index_sol=c(which.min(d)%%(2*ngrid),which.min(d)%/%(2*ngrid))
Ximg[index_sol[1],index_sol[2]]
Yimg[index_sol[1],index_sol[2]]
Zex[i]=sol_esatta[index_sol[1],index_sol[2]]
}
Z=Zex+rnorm(n,0,devst_noise)
}
}

